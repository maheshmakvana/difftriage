from __future__ import annotations
from typing import Any
import yaml
DEFAULT_CONFIG: dict[str, Any] = {
    "threshold": 50,
    "weights": {
        "complexity": 0.30,
        "test_impact": 0.25,
        "risky_files": 0.30,
        "dependency_config": 0.10,
        "ai_uncertainty": 0.05,
    },
    "rules": {"risky_path_patterns": ["auth", "billing", "migrations", ".github/workflows", "infra", "config"]},
}

def load_config(path: str | None) -> dict[str, Any]:
    if not path:
        return DEFAULT_CONFIG
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = yaml.safe_load(f) or {}
    except FileNotFoundError:
        return DEFAULT_CONFIG
    merged = DEFAULT_CONFIG.copy()
    merged["threshold"] = data.get("threshold", DEFAULT_CONFIG["threshold"])
    merged["weights"] = {**DEFAULT_CONFIG["weights"], **data.get("weights", {})}
    merged["rules"] = {**DEFAULT_CONFIG["rules"], **data.get("rules", {})}
    return merged