from __future__ import annotations
from difftriage.config import load_config
from difftriage.models import RiskInput, RiskReport

def _clamp(value: float, low: float = 0.0, high: float = 100.0) -> float:
    return max(low, min(high, value))

def _risk_level(score: float) -> str:
    if score >= 75:
        return "critical"
    if score >= 50:
        return "high"
    if score >= 25:
        return "medium"
    return "low"

def score_pr(risk_input: RiskInput, config_path: str | None = None, threshold_override: float | None = None) -> RiskReport:
    config = load_config(config_path)
    weights = config["weights"]
    patterns = config["rules"]["risky_path_patterns"]
    churn = risk_input.lines_added + risk_input.lines_deleted
    complexity = _clamp((risk_input.files_changed * 4) + (churn / 20))
    risky_hits = 0
    lowered = [p.lower() for p in risk_input.changed_paths]
    for path in lowered:
        if any(pattern.lower() in path for pattern in patterns):
            risky_hits += 1
    risky_files = _clamp((risky_hits / max(1, risk_input.files_changed)) * 100)
    test_impact = 0.0 if risk_input.tests_changed else _clamp(30 + (complexity * 0.5) + (risky_files * 0.2))
    dependency_config = 70.0 if risk_input.dependencies_changed else 0.0
    ai_uncertainty = _clamp(risk_input.ai_uncertainty_hits * 15)
    score = (
        complexity * weights["complexity"]
        + test_impact * weights["test_impact"]
        + risky_files * weights["risky_files"]
        + dependency_config * weights["dependency_config"]
        + ai_uncertainty * weights["ai_uncertainty"]
    )
    threshold = threshold_override if threshold_override is not None else float(config["threshold"])
    passed = score < threshold
    drivers: list[str] = []
    if risky_files >= 40:
        drivers.append("High share of risky paths changed")
    if test_impact >= 40:
        drivers.append("Insufficient test impact for changed code")
    if dependency_config > 0:
        drivers.append("Dependency or config change detected")
    if complexity >= 50:
        drivers.append("Large or complex diff")
    if ai_uncertainty > 0:
        drivers.append("AI uncertainty indicators present")
    if not drivers:
        drivers.append("No major risk driver detected")
    return RiskReport(score=round(score, 2), threshold=threshold, passed=passed, level=_risk_level(score), drivers=drivers)