import json
import typer
from difftriage.models import RiskInput
from difftriage.scoring import score_pr
app = typer.Typer(no_args_is_help=True)
@app.command()
def score(files_changed: int = typer.Option(...), lines_added: int = typer.Option(...), lines_deleted: int = typer.Option(...), changed_path: list[str] = typer.Option([]), tests_changed: bool = typer.Option(False), dependencies_changed: bool = typer.Option(False), ai_uncertainty_hits: int = typer.Option(0), config: str = typer.Option(".difftriage.yml"), threshold: float | None = typer.Option(None), output: str = typer.Option("text")) -> None:
    report = score_pr(RiskInput(files_changed=files_changed, lines_added=lines_added, lines_deleted=lines_deleted, changed_paths=changed_path, tests_changed=tests_changed, dependencies_changed=dependencies_changed, ai_uncertainty_hits=ai_uncertainty_hits), config_path=config, threshold_override=threshold)
    if output == "json":
        typer.echo(json.dumps(report.__dict__, indent=2))
    else:
        typer.echo(f"risk_score={report.score} level={report.level} threshold={report.threshold} passed={report.passed}")
        for driver in report.drivers:
            typer.echo(f"- {driver}")
    raise typer.Exit(code=0 if report.passed else 2)
if __name__ == "__main__":
    app()