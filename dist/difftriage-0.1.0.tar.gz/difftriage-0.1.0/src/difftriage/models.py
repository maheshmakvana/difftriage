from dataclasses import dataclass, field


@dataclass
class RiskInput:
    files_changed: int
    lines_added: int
    lines_deleted: int
    changed_paths: list[str] = field(default_factory=list)
    tests_changed: bool = False
    dependencies_changed: bool = False
    ai_uncertainty_hits: int = 0


@dataclass
class RiskReport:
    score: float
    threshold: float
    passed: bool
    level: str
    drivers: list[str]