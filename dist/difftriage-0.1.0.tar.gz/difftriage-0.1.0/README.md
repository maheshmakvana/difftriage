# DiffTriage

DiffTriage is a Python PR risk gate library for AI-assisted development.

It scores pull request risk using:
- Diff complexity (files and churn)
- Test impact (changed code without changed tests)
- Risky path changes (auth, billing, migrations, infra, CI)

It can fail CI when risk exceeds policy thresholds.

## Install

```bash
pip install difftriage
```

## Quick Start

```bash
difftriage score --files-changed 12 --lines-added 420 --lines-deleted 130 --changed-path src/auth.py --changed-path src/service.py --threshold 50
```

Exit codes:
- `0`: pass
- `2`: gate failed
- `1`: runtime/usage error

## Config

Place `.difftriage.yml` in repo root:

```yaml
threshold: 50
weights:
  complexity: 0.30
  test_impact: 0.25
  risky_files: 0.30
  dependency_config: 0.10
  ai_uncertainty: 0.05
rules:
  risky_path_patterns:
    - "auth"
    - "billing"
    - "migrations"
    - ".github/workflows"
```

## Verification Prompt (for this project)

Use this before release or major change:

1. Does the scoring output list top drivers clearly?
2. Is threshold behavior deterministic and tested?
3. Are false positives controlled for docs/tests-only changes?
4. Do CLI exit codes strictly match pass/fail/error policy?
5. Are packaging, build, and twine checks passing?
6. Does GitHub Actions run tests + build + twine check?
7. Is PyPI publish using Trusted Publishing (OIDC) only?

## PyPI + GitHub release model

- CI on PRs and main pushes
- Tag `vX.Y.Z` to release
- Trusted Publishing with `pypa/gh-action-pypi-publish`
- Manual approval via `pypi` environment