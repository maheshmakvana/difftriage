from difftriage.models import RiskInput
from difftriage.scoring import score_pr

def test_high_risk_without_tests_fails_gate() -> None:
    report = score_pr(RiskInput(files_changed=20, lines_added=800, lines_deleted=200, changed_paths=["src/auth/service.py", "src/billing/charge.py", ".github/workflows/ci.yml"], tests_changed=False, dependencies_changed=True, ai_uncertainty_hits=2), threshold_override=50)
    assert report.passed is False

def test_low_risk_with_tests_passes_gate() -> None:
    report = score_pr(RiskInput(files_changed=2, lines_added=20, lines_deleted=4, changed_paths=["src/utils/format.py", "tests/test_format.py"], tests_changed=True), threshold_override=50)
    assert report.passed is True